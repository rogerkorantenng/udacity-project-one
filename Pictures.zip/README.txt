CloudFront: https://d14ag9rym554m2.cloudfront.net
Website end-point: http://my-532570522518-bucket.s3-website-us-east-1.amazonaws.com

